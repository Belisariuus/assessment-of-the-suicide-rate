import setuptools

setuptools.setup(
    name="grpclib",
    python_requires='>=3.10',
)
